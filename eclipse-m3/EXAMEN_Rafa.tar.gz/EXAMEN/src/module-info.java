module EXAMEN {
	requires db4o.all.java5;
	requires java.sql;
}