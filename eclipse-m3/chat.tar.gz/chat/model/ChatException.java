package chat.model;

public class ChatException extends Exception{
	
	public ChatException(String msg){
		super(msg);
	}
}
