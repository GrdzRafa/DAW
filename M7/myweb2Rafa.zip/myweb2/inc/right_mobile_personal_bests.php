<div class="mobile-personal-bests">
	<h1><?php echo (isset($main_right_0300)) ? $main_right_0300 : "; "?></h1>
	<div class="personal-bests-container">
		<div class="best-item box-one">
			<p><?php echo (isset($main_right_0301)) ? $main_right_0301 : "; "?></p>
			<img src="../images/practica.png" alt="<?php echo (isset($main_right_0301)) ? strtolower($main_right_0301) : "; "?>" />
		</div>
		<div class="best-item box-two">
			<p><?php echo (isset($main_right_0302)) ? $main_right_0302 : "; "?></p>
			<img src="../images/form.png" alt="<?php echo (isset($main_right_0302)) ? strtolower($main_right_0302) : "; "?>" />
		</div>
		<div class="best-item box-three">
			<p><?php echo (isset($main_right_0303)) ? $main_right_0303 : "; "?></p>
			<img src="../images/lang.png" alt="<?php echo (isset($main_right_0303)) ? strtolower($main_right_0300) : "; "?>" />
		</div>
	</div>
</div>