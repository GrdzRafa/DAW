<div class="friends-activity">
	<h1><?php echo (isset($main_right_0400)) ? $main_right_0400 :"" ;?></h1>
	<div class="card-container">
		<div class="card">
			<div class="card-user-info">
				<img src="../images/jo.jpg" alt="" />
				<h2>Toni</h2>
			</div>
			<img class="card-img" src="../images/profe.jpg" alt="" />
			<p><?php echo (isset($main_right_0401)) ? $main_right_0401 :"" ;?></p>
		</div>

		<div class="card card-two">
			<div class="card-user-info">
				<img src="../images/jo.jpg" alt="" />
				<h2>Toni</h2>
			</div>
			<img class="card-img" src="../images/corr.jpg" alt="" />
			<p><?php echo (isset($main_right_0402)) ? $main_right_0402 :"" ;?></p>
		</div>
	</div>
</div>