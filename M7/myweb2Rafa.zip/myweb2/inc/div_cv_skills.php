<div class="skills">
	<h1><?php echo (isset($cv_skills_00)) ? $cv_skills_00 : "";?></h1>
	<div class="col-md-4">
		<section>
			<p>HTML5</p>
			<span class="full"></span><span class="full"></span><span
				class="full"></span><span class="full"></span><span class="full"></span>
		</section>

		<section>
			<p>CSS3</p>
			<span class="full"></span><span class="full"></span><span
				class="full"></span><span class="full"></span><span class="full"></span>
		</section>
		<section>
			<p>PHP</p>
			<span class="full"></span><span class="full"></span><span
				class="full"></span><span class="full"></span><span class="full"></span>
		</section>
		<section>
			<p>Java</p>
			<span class="full"></span><span class="full"></span><span
				class="full"></span><span class="full"></span><span class="full"></span>
		</section>
		<section>
			<p>Python</p>
			<span></span><span class="full"></span><span class="full"></span><span
				class="full"></span><span class="full"></span>
		</section>
		<section>
			<p>C++</p>
			<span class="full"></span><span class="full"></span><span
				class="full"></span><span class="full"></span><span class="full"></span>
		</section>
		<section>
			<p>Photoshop</p>
			<span class="full"></span><span class="full"></span><span
				class="full"></span><span class="full"></span><span class="full"></span>
		</section>
	</div>
	<div class="col-md-4">
		<section>
			<p>Domios</p>
			<span></span><span></span><span class="full"></span><span
				class="full"></span><span class="full"></span>
		</section>
		<section>
			<p>Bootstrap</p>
			<span></span><span></span><span class="full"></span><span
				class="full"></span><span class="full"></span>
		</section>
		<section>
			<p>Workpress</p>
			<span></span><span class="full"></span><span class="full"></span><span
				class="full"></span><span class="full"></span>
		</section>
		<section>
			<p>Woocommerce</p>
			<span></span><span class="full"></span><span class="full"></span><span
				class="full"></span><span class="full"></span>
		</section>
		<section>
			<p>Javascript</p>
			<span></span><span></span><span class="full"></span><span
				class="full"></span><span class="full"></span>
		</section>
		<section>
			<p>Illustrator</p>
			<span></span><span class="full"></span><span class="full"></span><span
				class="full"></span><span class="full"></span>
		</section>
		<section>
			<p>Hosting</p>
			<span></span><span class="full"></span><span class="full"></span><span
				class="full"></span><span class="full"></span>
		</section>
	</div>
	<div class="col-md-4">
		<section>
			<p>Mysql</p>
			<span class="full"></span><span class="full"></span><span
				class="full"></span><span class="full"></span><span class="full"></span>
		</section>
		<section>
			<p>OracleDB</p>
			<span class="full"></span><span class="full"></span><span
				class="full"></span><span class="full"></span><span class="full"></span>
		</section>
		<section>
			<p>Prestashop</p>
			<span></span><span class="full"></span><span class="full"></span><span
				class="full"></span><span class="full"></span>
		</section>
		<section>
			<p>Joomla!</p>
			<span></span><span class="full"></span><span class="full"></span><span
				class="full"></span><span class="full"></span>
		</section>
		<section>
			<p>SEO</p>
			<span></span><span></span><span class="full"></span><span
				class="full"></span><span class="full"></span>
		</section>
		<section>
			<p>Ajax</p>
			<span></span><span></span><span class="full"></span><span
				class="full"></span><span class="full"></span>
		</section>
		<section>
			<p>VisualBasic</p>
			<span class="full"></span><span class="full"></span><span
				class="full"></span><span class="full"></span><span class="full"></span>
		</section>
	</div>


</div>