<div class="right-content">
	<?php include "../inc/right_user_info.php";?>
	<?php include "../inc/right_lang.php";?>
	<?php include "../inc/right_mobile_personal_bests.php";?>
	<?php include "../inc/right_friends_activity.php";?>
</div>