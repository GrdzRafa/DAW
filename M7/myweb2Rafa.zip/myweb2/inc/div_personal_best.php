<div class="personal-bests">
	<h1><?php echo (isset($main_left_0200)) ? $main_left_0200 : ""; ?></h1>
	<div class="personal-bests-container">
		<div class="best-item box-one">
			<a href="activities.php">
				<p><?php echo (isset($main_left_0201)) ? $main_left_0201 : ""; ?></p> 
				<img src="../images/practicas.png" alt="<?php echo (isset($main_left_0201)) ? strtolower($main_left_0201) : ""; ?>" />
			</a>
		</div>

		<div class="best-item box-two">
			<a href="ibex35.php">
    			<p><?php echo (isset($main_left_0202)) ? $main_left_0202 : ""; ?></p>
    			<img src="../images/form.png" alt="<?php echo (isset($main_left_0202)) ? strtolower($main_left_0202) : ""; ?>" />
			</a>
		</div>
		<div class="best-item box-three">
			<p><?php echo (isset($main_left_0203)) ? $main_left_0203 : ""; ?></p>
			<img src="../images/lang.png" alt="<?php echo (isset($main_left_0203)) ? strtolower($main_left_0203) : ""; ?>" />
		</div>
	</div>
</div>