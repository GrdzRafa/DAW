<?php
// Configuració de l'aplicació
// Accés a la base de dades
$dbParams = [
    'driver' =>'pdo_mysql' ,
    'host' =>'localhost' ,
    'dbname' =>'doctrine_GrdzRafa',
    'user' =>'usr_generic' ,
    'password' =>'2025@Thos'
];
// Estem en mode desenvolupament?
$dev = true;