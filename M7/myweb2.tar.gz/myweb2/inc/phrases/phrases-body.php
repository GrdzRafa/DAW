<link rel="stylesheet" href="../inc/event/style.css">
</head>
<?php include "../inc/main-menu.php"; ?>
<body>
<main>
<section class="content">
	<div>
		<button><a href="?Phrase/show">Veure frases</a></button>
		<button><a href="?Author/show">Veure autors</a></button>
		<button><a href="?Theme/show">Veure temes</a></button>
		<button>Carregar XML</button>
	</div>

