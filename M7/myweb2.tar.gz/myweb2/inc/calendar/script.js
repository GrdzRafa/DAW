//// script.js
//
//document.addEventListener('DOMContentLoaded', function() {
//    // Aquí puedes agregar cualquier funcionalidad adicional de JavaScript
//    const form = document.getElementById('calendarForm');
//
//    // Ejemplo: Manejar el evento de envío del formulario
//    form.addEventListener('submit', function(event) {
//        // Puedes realizar validaciones aquí si es necesario
//        console.log("Formulario enviado con la fecha: " + form.date.value);
//    });
//});