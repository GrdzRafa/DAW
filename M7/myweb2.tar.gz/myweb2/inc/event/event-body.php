<link rel="stylesheet" href="../inc/event/style.css">
</head>
<?php include "../inc/main-menu.php"; ?>
<body>
<main>
<section class="content">
	<h1 style="text-align: center;">Tabla de Eventos</h1>
	<table id="#event-table">
		<tr>
			<th>Id</th>
			<th>Nombre del Evento</th>
			<th>Data i hora inici</th>
			<th>Data i hora final</th>
			<th>Lugar</th>
			<th>Descripción</th>
			<th>Accions</th>
		</tr>
