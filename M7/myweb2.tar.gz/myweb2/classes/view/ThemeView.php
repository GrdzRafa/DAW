<?php

class ThemeView extends View
{
    public function show($llistatTemes)
    {
        //         echo "<pre>";
        //         echo var_dump($llistatAutors);
        //         echo "</pre>";
        include $this->file;
        echo "<!DOCTYPE html><html lang=\"en\">";
        include "../inc/head.php";
        include "../inc/phrases/phrases-body.php";
        echo "<table id=\"#event-table\">";
        echo "<tr>";
        echo "<th>Tema</th>";
        echo "<th>Desripcio</th>";
        echo "<th>Num. de frases</th>";
        echo "<th>Acció</th>";
        echo "</tr>";
        
        foreach ($llistatTemes as $theme) {
            echo "<tr>";
            echo "<td>".$theme->nom."</td>";
            echo "<td>".$theme->descripcio."</td>";
            echo "<td>".$theme->numFrases."</td>";
            echo "<td class=\"icon\">";
            echo "<form method='POST' action='?Event/delete' onsubmit='return confirm(\"Estàs segur de voler eliminar aquesta frase?\")'>";
            echo "<input type='hidden' name='delete-event-id' value='{$theme->id}'>";
            echo "<button type='submit' class='delete-btn'><i class=\"far fa-trash-alt\"></i></button>";
            echo "</form>";
            
            echo "<a href='editEvent.php?id={$theme->id}'><i class=\"fas fa-edit\"></i></a>";
            
            echo "</td>";
            echo "</tr>";
        }
        
        echo "</table></section></main></body></html>";
    }
}

