<?php

class ThemeController extends Controller
{
    public function show($params=null) {
        
        $llistatTemes = ThemeDAO::getAll();
        $vTheme = new ThemeView();
        $vTheme->show($llistatTemes);
    }
}

