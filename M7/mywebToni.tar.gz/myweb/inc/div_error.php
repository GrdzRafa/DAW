<div class="calendar-container__header">
	<h2 class="calendar-container__btn">Hi ha un problema</h2>
	<h3 class="calendar-container__title"><?php echo $e->getMessage();?></h3>
</div>
<div style="margin: 0 auto;">
	<img style="width:100%" src="../images/error.png"/>
</div>