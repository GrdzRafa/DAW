<div class="calendar-container__header">
	<h2 class="calendar-container__btn"><?php echo $titol;?></h2>
	<h4 class="calendar-container__header"><?php echo $missatge;?></h4>
</div>