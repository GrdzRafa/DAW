<div class="cv left-content">
	<?php include "../inc/div_cv_skills.php"; ?>
	
	<div class="left-bottom">
		<?php include "../inc/div_cv_left_bottom.php"; ?>
		<?php include "../inc/div_cv_weekly_schedule.php"; ?>
	</div>
</div>