<div class="left-content">
	<?php include "../inc/div_actitities.php";?>
	<?php include "../inc/div_left_bottom.php";?>	
</div>