<?php
$head_title = "Thos i Codina - 서버 환경에서 웹 개발";

$nav_01 = "메인";
$nav_02 = "프로필";
$nav_03 = "일정";
$nav_04 = "활동";
$nav_05 = "설정";
$nav_06 = "유지관리";

$main_left_01 = "CFGS 웹 애플리케이션 개발 - 서버 환경에서 웹 개발";
$main_left_02 = "php 소개";
$main_left_03 = "기존 요소";
$main_left_04 = "객체 지향 프로그래밍";
$main_left_05 = "디자인 패턴";
$main_left_06 = "동적 페이지";
$main_left_07 = "지속성";
$main_left_0100 = "프로그래밍";
$main_left_0101 = "UF1";
$main_left_0102 = "11Nov24";
$main_left_0103 = "서버 환경에서 웹 개발";
$main_left_0104 = "UF2";
$main_left_0105 = "25년 1월 27일";
$main_left_0106 = "웹페이지의 동적 생성";
$main_left_0107 = "UF3";
$main_left_0108 = "11Mar25";
$main_left_0109 = "데이터 접근 기술";
$main_left_0110 = "UF4";
$main_left_0111 = "25년 5월 31일";
$main_left_0112 = "웹 서비스. 대화형 동적 페이지. 하이브리드 웹사이트";
$main_left_0113 = "보기";
$main_left_0200 = "연습";
$main_left_0201 = "초기 실행";
$main_left_0202 = "양식";
$main_left_0203 = "언어";

$main_right_0101 = "로그인";
$main_right_0201 = "강좌 개발";
$main_right_0300 = "연습";
$main_right_0301 = "초기 연습";
$main_right_0302 = "양식";
$main_right_0303 = "언어";
$main_right_0400 = "나는 지금 무엇을 하고 있는가";
$main_right_0401 = "나의 주요 목표는 귀하의 학습과 발전을 촉진하는 것입니다.";
$main_right_0402 = "이 과정에서 도움을 주세요 💪";

$cv_skills_00 = "스킬";
$cv_exp_00 = "경험치";