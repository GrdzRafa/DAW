<?php
$head_title = "Thos i Codina - Desenvolupament web en entorn servidor";

$nav_01 = "Principal";
$nav_02 = "Perfil";
$nav_03 = "Horari";
$nav_04 = "Activitats";
$nav_05 = "Configuracions";
$nav_06 = "Manteniment";

$main_left_01 = "CFGS desenvolupament d'aplicacions web - desenvolupament web en entorn servidor";
$main_left_02 = "Introducció al php";
$main_left_03 = "Elements del lleguatge";
$main_left_04 = "Programació orientada a objecte";
$main_left_05 = "Patrons de disseny";
$main_left_06 = "Pàgines dinàmiques";
$main_left_07 = "Persistència";
$main_left_0100 = "Programació";
$main_left_0101 = "UF1";
$main_left_0102 = "11nov24";
$main_left_0103 = "Desenvolupament web en entorn servidor";
$main_left_0104 = "UF2";
$main_left_0105 = "27gen25";
$main_left_0106 = "Generació dinàmica de pagines web";
$main_left_0107 = "UF3";
$main_left_0108 = "11mar25";
$main_left_0109 = "Tècniques d’accés a dades";
$main_left_0110 = "UF4";
$main_left_0111 = "31mai25";
$main_left_0112 = "Serveis web. Pàgines dinàmiques interactives. Webs Híbrids";
$main_left_0113 = "Veure";
$main_left_0200 = "Pràctiques";
$main_left_0201 = "Pràctiques inicials";
$main_left_0202 = "Cotitzacions Inversis";
$main_left_0203 = "Idiomes";

$main_right_0101 = "Accedeix";
$main_right_0201 = "Desenvolupament del curs";
$main_right_0300 = "Pràctiques";
$main_right_0301 = "Pràctiques inicial";
$main_right_0302 = "Formularis";
$main_right_0303 = "Idiomes";
$main_right_0400 = "Què estic fent en aquest moment";
$main_right_0401 = "El meu objectiu principal és facilitar el vostre aprenentatge i desenvolupament.";
$main_right_0402 = "i ajudar-vos en el procés 💪";

$cv_skills_00 = "Habilitats";
$cv_exp_00 = "Experiència";
