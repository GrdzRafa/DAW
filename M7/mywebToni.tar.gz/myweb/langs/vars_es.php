<?php 
$head_title = "Thos y Codina - Desarrollo web en entorno servidor";

$nav_01 = "Principal";
$nav_02 = "Perfil";
$nav_03 = "Horario";
$nav_04 = "Actividades";
$nav_05 = "Configuraciones";
$nav_06 = "Mantenimiento";

$main_left_01 = "CFGS desarrollo de aplicaciones web - desarrollo web en entorno servidor";
$main_left_02 = "Introducción al php";
$main_left_03 = "Elementos del lenguaje";
$main_left_04 = "Programación orientada a objeto";
$main_left_05 = "Patrones de diseño";
$main_left_06 = "Páginas dinámicas";
$main_left_07 = "Persistencia";
$main_left_0100 = "Programación";
$main_left_0101 = "UF1";
$main_left_0102 = "11nov24";
$main_left_0103 = "Desarrollo web en entorno servidor";
$main_left_0104 = "UF2";
$main_left_0105 = "27ene25";
$main_left_0106 = "Generación dinámica de paginas web";
$main_left_0107 = "UF3";
$main_left_0108 = "11mar25";
$main_left_0109 = "Técnicas de acceso a datos";
$main_left_0110 = "UF4";
$main_left_0111 = "31may25";
$main_left_0112 = "Servicios web. Páginas dinámicas interactivas. Webs Híbridos";
$main_left_0113 = "Ver";
$main_left_0200 = "Prácticas";
$main_left_0201 = "Prácticas iniciales";
$main_left_0202 = "Cotizaciones Inversis";
$main_left_0203 = "Idiomas";

$main_right_0101 = "Acceder";
$main_right_0201 = "Desarrollo del curso";
$main_right_0300 = "Prácticas";
$main_right_0301 = "Prácticas inicial";
$main_right_0302 = "Formularios";
$main_right_0303 = "Idiomas";
$main_right_0400 = "¿Qué estoy haciendo en ese momento";
$main_right_0401 = "Mi objetivo principal es facilitar su aprendizaje y desarrollo.";
$main_right_0402 = "y ayudarle en el proceso 💪";

$cv_skills_00 = "Habilidades";
$cv_exp_00 = "Experiencia";