<?php
$head_title = "Thos eta Codina - Web garapena zerbitzari-ingurunean";

$nav_01 = "Nagusia";
$nav_02 = "Profila";
$nav_03 = "Egitaraua";
$nav_04 = "Jarduerak";
$nav_05 = "Ezarpenak";
$nav_06 = "Iraupena";

$main_left_01 = "CFGS web aplikazioen garapena - web garapena zerbitzari-ingurunean";
$main_left_02 = "php-ren sarrera";
$main_left_03 = "Oinarrizko elementuak";
$main_left_04 = "Objektuetara zuzendutako programazioa";
$main_left_05 = "Diseinu-ereduak";
$main_left_06 = "Orri dinamikoak";
$main_left_07 = "Iraunkortasuna";
$main_left_0100 = "Programazioa";
$main_left_0101 = "UF1";
$main_left_0102 = "11Aza24";
$main_left_0103 = "Web garapena zerbitzari-ingurunean";
$main_left_0104 = "UF2";
$main_left_0105 = "27Urt25";
$main_left_0106 = "Web orrien sorkuntza dinamikoa";
$main_left_0107 = "UF3";
$main_left_0108 = "11Mar25";
$main_left_0109 = "Datuak sartzeko teknikak";
$main_left_0110 = "UF4";
$main_left_0111 = "31Mai25";
$main_left_0112 = "Web zerbitzuak. Orrialde dinamiko interaktiboak. Webgune hibridoak";
$main_left_0113 = "Ikusi";
$main_left_0200 = "Praktikak";
$main_left_0201 = "Hasierako praktikak";
$main_left_0202 = "Aipamenak Inversis";
$main_left_0203 = "Hizkuntzak";

$main_right_0101 = "Sartu saioa";
$main_right_0201 = "Ikastaroaren garapena";
$main_right_0300 = "Praktikak";
$main_right_0301 = "Hasierako praktika";
$main_right_0302 = "Inprimakiak";
$main_right_0303 = "Hizkuntzak";
$main_right_0400 = "Zer egiten ari naiz une honetan";
$main_right_0401 = "Nire helburu nagusia zure ikaskuntza eta garapena erraztea da.";
$main_right_0402 = "eta prozesuan lagundu 💪";

$cv_skills_00 = "Trebetasunak";
$cv_exp_00 = "Esperientzia";