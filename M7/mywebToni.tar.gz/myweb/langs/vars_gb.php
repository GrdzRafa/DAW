<?php
$head_title = "Thos and Codina - Web development in a server environment";

$nav_01 = "Main";
$nav_02 = "Profile";
$nav_03 = "Schedule";
$nav_04 = "Activities";
$nav_05 = "Settings";
$nav_06 = "Maintenance";

$main_left_01 = "CFGS web application development - web development in a server environment";
$main_left_02 = "Introduction to php";
$main_left_03 = "Legacy elements";
$main_left_04 = "Object Oriented Programming";
$main_left_05 = "Design Patterns";
$main_left_06 = "Dynamic Pages";
$main_left_07 = "Persistence";
$main_left_0100 = "Programming";
$main_left_0101 = "UF1";
$main_left_0102 = "11Nov24";
$main_left_0103 = "Web development in a server environment";
$main_left_0104 = "UF2";
$main_left_0105 = "27Jan25";
$main_left_0106 = "Dynamic generation of web pages";
$main_left_0107 = "UF3";
$main_left_0108 = "11Mar25";
$main_left_0109 = "Data access techniques";
$main_left_0110 = "UF4";
$main_left_0111 = "31May25";
$main_left_0112 = "Web services. Interactive dynamic pages. Hybrid websites";
$main_left_0113 = "View";
$main_left_0200 = "Practices";
$main_left_0201 = "Initial practices";
$main_left_0202 = "Quotations Inversis";
$main_left_0203 = "Languages";

$main_right_0101 = "Log in";
$main_right_0201 = "Course development";
$main_right_0300 = "Practices";
$main_right_0301 = "Initial practice";
$main_right_0302 = "Forms";
$main_right_0303 = "Languages";
$main_right_0400 = "What am I doing right now";
$main_right_0401 = "My main goal is to facilitate your learning and development.";
$main_right_0402 = "and help you in the process 💪";

$cv_skills_00 = "Skills";
$cv_exp_00 = "Experience";