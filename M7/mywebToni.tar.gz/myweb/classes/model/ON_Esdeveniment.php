<?php

class ON_Esdeveniment {
    public $id;
    public $dataInici;
    public $horaInici;
    public $final;
    public $titol;
    public $contingut;
    
    public $errorsDetectats;
}

