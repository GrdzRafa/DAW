<head>
	<meta charset="UTF-8">
	<title>
		<?php echo (isset($head_title)) ? $head_title : ""; ?></title>
	<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css'>
	<link rel="stylesheet" href="../css/style.css?v=2.03">
</head>