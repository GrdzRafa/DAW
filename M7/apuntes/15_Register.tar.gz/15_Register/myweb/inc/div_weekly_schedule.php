<div class="weekly-schedule">
	<h1><?php echo (isset($main_left_0100)) ? $main_left_0100 : "";?></h1>
	<div class="calendar">
		<div class="day-and-activity activity-one">
			<div class="day">
				<h1><?php echo (isset($main_left_0101)) ? $main_left_0101 : "";?></h1>
				<p><?php echo (isset($main_left_0102)) ? $main_left_0102 : "";?></p>
			</div>
			<div class="activity">
				<h2><?php echo (isset($main_left_0103)) ? $main_left_0103 : "";?></h2>
			</div>
			<a href="programacioUF1.php">
				<button class="btn"><?php echo (isset($main_left_0113)) ? $main_left_0113 : "";?></button>
			</a>
		</div>

		<div class="day-and-activity activity-two">
			<div class="day">
				<h1><?php echo (isset($main_left_0104)) ? $main_left_0104 : "";?></h1>
				<p><?php echo (isset($main_left_0105)) ? $main_left_0105 : "";?></p>
			</div>
			<div class="activity">
				<h2><?php echo (isset($main_left_0106)) ? $main_left_0106 : "";?></h2>
			</div>
			<a href="programacioUF2.php">
				<button class="btn"><?php echo (isset($main_left_0113)) ? $main_left_0113 : "";?></button>
			</a>
		</div>

		<div class="day-and-activity activity-three">
			<div class="day">
				<h1><?php echo (isset($main_left_0107)) ? $main_left_0107 : "";?></h1>
				<p><?php echo (isset($main_left_0108)) ? $main_left_0108 : "";?></p>
			</div>
			<div class="activity">
				<h2><?php echo (isset($main_left_0109)) ? $main_left_0109 : "";?></h2>
			</div>
			<a href="programacioUF3.php">
				<button class="btn"><?php echo (isset($main_left_0113)) ? $main_left_0113 : "";?></button>
			</a>
		</div>

		<div class="day-and-activity activity-four">
			<div class="day">
				<h1><?php echo (isset($main_left_0110)) ? $main_left_0110 : "";?></h1>
				<p><?php echo (isset($main_left_0111)) ? $main_left_0111 : "";?></p>
			</div>
			<div class="activity">
				<h2><?php echo (isset($main_left_0112)) ? $main_left_0112 : "";?></h2>
			</div>
			<a href="programacioUF4.php">
				<button class="btn"><?php echo (isset($main_left_0113)) ? $main_left_0113 : "";?></button>
			</a>
		</div>
	</div>
</div>
