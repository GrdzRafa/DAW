<div class="left-bottom">
	<?php include "../inc/div_weekly_schedule.php"; ?>
	<?php include "../inc/div_personal_best.php"; ?>
</div>
