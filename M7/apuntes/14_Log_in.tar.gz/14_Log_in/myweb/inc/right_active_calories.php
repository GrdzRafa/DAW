<div class="active-calories">
	<h1 style="align-self: flex-start"><?php echo (isset($main_right_0201)) ? $main_right_0201 : ""; ?></h1>
	<div class="active-calories-container">
		<div class="box" style="--i: 1%">
			<div class="circle">
				<h2>
					1<small>%</small>
				</h2>
			</div>
		</div>
	</div>
</div>