<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Thos i Codina - Desenvolupament web en entorn servidor</title>
	<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css'>
	<link rel="stylesheet" href="../css/style.css?v=1.2">
</head>
<body>
	<main>
		<nav class="main-menu">
			<h1><img class="logo" src="../images/logo.png" alt="" /></h1>
			<h1>DAW M07</h1>
			<ul>
				<li class="nav-item"><b></b> <b></b> 
					<a href="index.php"> 
						<i class="fa fa-house nav-icon"></i> 
						<span class="nav-text">Home</span>
					</a>
				</li>

				<li class="nav-item"><b></b> <b></b> 
					<a href="profile.php"> 
						<i class="fa fa-user nav-icon"></i> 
						<span class="nav-text">Profile</span>
					</a>
				</li>

				<li class="nav-item"><b></b> <b></b> 
					<a href="schedule2409.php"> 
						<i class="fa fa-calendar-check nav-icon"></i> 
						<span class="nav-text">Schedule</span>
					</a>
				</li>

				<li class="nav-item"><b></b> <b></b> 
					<a href="activities.php"> 
						<i class="fa fa-person-running nav-icon"></i> 
						<span class="nav-text">Activities</span>
					</a>
				</li>

				<li class="nav-item"><b></b> <b></b> 
					<a href="settings.php"> 
						<i class="fa fa-sliders nav-icon"></i> 
						<span class="nav-text">Settings</span>
					</a>
				</li>
			</ul>
		</nav>


		<div class="left-content">
		<img style="width:75%; margin: 0 auto;" src="../images/en-construccio.jpg"/>	

</div>
	</main>
</body>
</html>
