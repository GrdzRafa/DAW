<?php
$head_title = "Thos und Codina – Webentwicklung in einer Serverumgebung";

$nav_01 = "Haupt";
$nav_02 = "Profil";
$nav_03 = "Zeitplan";
$nav_04 = "Aktivitäten";
$nav_05 = "Einstellungen";

$main_left_01 = "CFGS-Webanwendungsentwicklung – Webentwicklung in einer Serverumgebung";
$main_left_02 = "Einführung in PHP";
$main_left_03 = "Legacy-Elemente";
$main_left_04 = "Objektorientierte Programmierung";
$main_left_05 = "Entwurfsmuster";
$main_left_06 = "Dynamische Seiten";
$main_left_07 = "Persistenz";
$main_left_0100 = "Programmierung";
$main_left_0101 = "UF1";
$main_left_0102 = "11Nov24";
$main_left_0103 = "Webentwicklung in einer Serverumgebung";
$main_left_0104 = "UF2";
$main_left_0105 = "27Jan25";
$main_left_0106 = "Dynamische Generierung von Webseiten";
$main_left_0107 = "UF3";
$main_left_0108 = "11Mär25";
$main_left_0109 = "Datenzugriffstechniken";
$main_left_0110 = "UF4";
$main_left_0111 = "31Mai25";
$main_left_0112 = "Webdienste. Interaktive dynamische Seiten. Hybride Websites";
$main_left_0113 = "Ansicht";
$main_left_0200 = "Übungen";
$main_left_0201 = "Erste Übungen";
$main_left_0202 = "Inversis Zitate";
$main_left_0203 = "Sprachen";

$main_right_0101 = "Anmelden";
$main_right_0201 = "Kursentwicklung";
$main_right_0300 = "Praktiken";
$main_right_0301 = "Erste Übung";
$main_right_0302 = "Formulare";
$main_right_0303 = "Sprachen";
$main_right_0400 = "Was mache ich gerade";
$main_right_0401 = "Mein Hauptziel ist es, Ihr Lernen und Ihre Entwicklung zu erleichtern.";
$main_right_0402 = "und Ihnen dabei helfen 💪";

$cv_skills_00 = "Fähigkeiten";
$cv_exp_00 = "Erfahrung";