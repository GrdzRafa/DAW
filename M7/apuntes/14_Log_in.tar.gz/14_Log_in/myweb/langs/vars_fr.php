<?php
$head_title = "Thos et Codina - Développement Web dans un environnement serveur";

$nav_01 = "Principal";
$nav_02 = "Profil";
$nav_03 = "Horaire";
$nav_04 = "Activités";
$nav_05 = "Paramètres";

$main_left_01 = "Développement d'applications Web CFGS - développement Web dans un environnement serveur";
$main_left_02 = "Introduction à php";
$main_left_03 = "Éléments hérités";
$main_left_04 = "Programmation Orientée Objet";
$main_left_05 = "Modèles de conception";
$main_left_06 = "Pages dynamiques";
$main_left_07 = "Persistance";
$main_left_0100 = "Programmation";
$main_left_0101 = "UF1";
$main_left_0102 = "11nov24";
$main_left_0103 = "Développement Web dans un environnement serveur";
$main_left_0104 = "UF2";
$main_left_0105 = "27jan25";
$main_left_0106 = "Génération dynamique de pages web";
$main_left_0107 = "UF3";
$main_left_0108 = "11Mar25";
$main_left_0109 = "Techniques d'accès aux données";
$main_left_0110 = "UF4";
$main_left_0111 = "31Mai25";
$main_left_0112 = "Services Web. Pages dynamiques interactives. Sites Web hybrides";
$main_left_0113 = "Afficher";
$main_left_0200 = "Pratiques";
$main_left_0201 = "Pratiques initiales";
$main_left_0202 = "Citacions Inversis";
$main_left_0203 = "Langues";

$main_right_0101 = "Connexion";
$main_right_0201 = "Développement de cours";
$main_right_0300 = "Pratiques";
$main_right_0301 = "Pratique initiale";
$main_right_0302 = "Formulaires";
$main_right_0303 = "Langues";
$main_right_0400 = "Qu'est-ce que je fais en ce moment";
$main_right_0401 = "Mon objectif principal est de faciliter votre apprentissage et votre développement.";
$main_right_0402 = "et vous aider dans le processus 💪";

$cv_skills_00 = "Compétences";
$cv_exp_00 = "Expérience";