class DorsalRepetitException extends Exception {
    public DorsalRepetitException(String message) {
        super(message);
    }
}