
class JugadorsPerPosicioException extends Exception {
    public JugadorsPerPosicioException(String message) {
        super(message);
    }
}
