package vistes;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Font;
import javax.swing.JLabel;

public class VistaPrincipal extends JFrame {

	private static final long serialVersionUID = 1245745L;
	private JPanel contentPane;
	private JTextField textField_1;
	private JButton btnNewButton;
	private JButton btnNewButton_1;
	private JButton btnNewButton_2;
	private JButton btnNewButton_3;
	private JButton btnNewButton_5;
	private JButton btnNewButton_1_1;
	private JButton btnNewButton_2_1;
	private JButton btnNewButton_3_1;
	private JButton btnNewButton_6;
	private JButton btnNewButton_1_2;
	private JButton btnNewButton_2_2;
	private JButton btnNewButton_7;
	private JButton btnNewButton_1_3;
	private JButton btnNewButton_2_3;
	private JButton btnNewButton_2_4;
	private JTextField textField;
	private JButton btnNewButton_3_2;



	public VistaPrincipal() {
		setBackground(new Color(97, 53, 131));
		setForeground(new Color(192, 28, 40));
		initComponents();
		initEventHandlers();
	}



	private void initEventHandlers() {

	}



	private void initComponents() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 301, 550);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(192, 191, 188));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("DialogInput", Font.BOLD, 20));
		textField_1.setForeground(new Color(224, 27, 36));
		textField_1.setBackground(new Color(94, 92, 100));
		textField_1.setColumns(10);
		textField_1.setBounds(12, 32, 272, 66);
		contentPane.add(textField_1);
		
		btnNewButton = new JButton("7");
		btnNewButton.setFont(new Font("DialogInput", Font.BOLD, 20));
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.setForeground(new Color(165, 29, 45));
		btnNewButton.setBounds(32, 257, 50, 50);
		
//		btnNewButton.setBackground(new Color(173, 216, 230)); // Color de fondo
		btnNewButton.setOpaque(true);
		btnNewButton.setFocusPainted(false); // Elimina el borde de enfoque
		btnNewButton.setBorder(BorderFactory.createCompoundBorder(
		    BorderFactory.createBevelBorder(BevelBorder.RAISED), // Relieve elevado
		    BorderFactory.createEmptyBorder(5, 15, 5, 15)        // Espaciado interior
		));


		contentPane.add(btnNewButton);
		
		btnNewButton_1 = new JButton("8");
		btnNewButton_1.setFont(new Font("DialogInput", Font.BOLD, 20));
		
		btnNewButton_1.setBackground(new Color(255, 255, 255));
		btnNewButton_1.setForeground(new Color(165, 29, 45));
		btnNewButton_1.setBounds(94, 257, 50, 50);
		contentPane.add(btnNewButton_1);
		btnNewButton_2 = new JButton("9");
		btnNewButton_2.setFont(new Font("DialogInput", Font.BOLD, 20));
		btnNewButton_2.setBackground(new Color(255, 255, 255));
		btnNewButton_2.setForeground(new Color(165, 29, 45));
		btnNewButton_2.setBounds(156, 257, 50, 50);
		contentPane.add(btnNewButton_2);
		
		btnNewButton_3 = new JButton("AC");
		btnNewButton_3.setFont(new Font("DialogInput", Font.BOLD, 20));
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		
		btnNewButton_3.setBackground(new Color(165, 29, 45));
		btnNewButton_3.setForeground(new Color(255, 255, 255));
		btnNewButton_3.setBounds(32, 192, 112, 50);
		contentPane.add(btnNewButton_3);
		
		btnNewButton_5 = new JButton("4");
		btnNewButton_5.setFont(new Font("DialogInput", Font.BOLD, 20));
		
		btnNewButton_5.setBackground(new Color(255, 255, 255));
		btnNewButton_5.setForeground(new Color(165, 29, 45));
		btnNewButton_5.setBounds(33, 319, 50, 50);
		contentPane.add(btnNewButton_5);
		
		btnNewButton_1_1 = new JButton("5");
		btnNewButton_1_1.setFont(new Font("DialogInput", Font.BOLD, 20));
		
		btnNewButton_1_1.setBackground(new Color(255, 255, 255));
		btnNewButton_1_1.setForeground(new Color(165, 29, 45));
		btnNewButton_1_1.setBounds(94, 319, 50, 50);
		contentPane.add(btnNewButton_1_1);
		
		btnNewButton_2_1 = new JButton("6");
		btnNewButton_2_1.setFont(new Font("DialogInput", Font.BOLD, 20));
		
		btnNewButton_2_1.setBackground(new Color(255, 255, 255));
		btnNewButton_2_1.setForeground(new Color(165, 29, 45));
		btnNewButton_2_1.setBounds(156, 319, 50, 50);
		contentPane.add(btnNewButton_2_1);
		
		btnNewButton_3_1 = new JButton("X");
		btnNewButton_3_1.setFont(new Font("DialogInput", Font.BOLD, 20));
		
		btnNewButton_3_1.setBackground(new Color(165, 29, 45));
		btnNewButton_3_1.setForeground(new Color(255, 255, 255));
		btnNewButton_3_1.setBounds(156, 192, 50, 50);
		contentPane.add(btnNewButton_3_1);
		
		btnNewButton_6 = new JButton("1");
		btnNewButton_6.setFont(new Font("DialogInput", Font.BOLD, 20));
		btnNewButton_6.setBackground(new Color(255, 255, 255));
		btnNewButton_6.setForeground(new Color(165, 29, 45));
		btnNewButton_6.setBounds(32, 381, 50, 50);
		contentPane.add(btnNewButton_6);
		
		btnNewButton_1_2 = new JButton("2");
		btnNewButton_1_2.setFont(new Font("DialogInput", Font.BOLD, 20));
		btnNewButton_1_2.setBackground(new Color(255, 255, 255));
		btnNewButton_1_2.setForeground(new Color(165, 29, 45));
		btnNewButton_1_2.setBounds(94, 381, 50, 50);
		contentPane.add(btnNewButton_1_2);
		
		btnNewButton_2_2 = new JButton("3");
		btnNewButton_2_2.setFont(new Font("DialogInput", Font.BOLD, 20));

		btnNewButton_2_2.setBackground(new Color(255, 255, 255));
		btnNewButton_2_2.setForeground(new Color(165, 29, 45));
		btnNewButton_2_2.setBounds(156, 381, 50, 50);
		contentPane.add(btnNewButton_2_2);
		
		btnNewButton_7 = new JButton("0");
		btnNewButton_7.setFont(new Font("DialogInput", Font.BOLD, 20));

		btnNewButton_7.setBackground(new Color(255, 255, 255));
		btnNewButton_7.setForeground(new Color(165, 29, 45));
		btnNewButton_7.setBounds(32, 443, 112, 50);
		contentPane.add(btnNewButton_7);
		
		btnNewButton_1_3 = new JButton(".");
		btnNewButton_1_3.setFont(new Font("DialogInput", Font.BOLD, 20));

		btnNewButton_1_3.setBackground(new Color(255, 255, 255));
		btnNewButton_1_3.setForeground(new Color(165, 29, 45));
		btnNewButton_1_3.setBounds(156, 443, 50, 50);
		contentPane.add(btnNewButton_1_3);
		
		btnNewButton_2_3 = new JButton("=");
		btnNewButton_2_3.setFont(new Font("DialogInput", Font.BOLD, 20));

		btnNewButton_2_3.setBackground(new Color(165, 29, 45));
		btnNewButton_2_3.setForeground(new Color(255, 255, 255));
		btnNewButton_2_3.setBounds(218, 381, 50, 112);
		contentPane.add(btnNewButton_2_3);
		
		btnNewButton_3_2 = new JButton("C");
		btnNewButton_3_2.setFont(new Font("DialogInput", Font.BOLD, 20));
		btnNewButton_3_2.setForeground(new Color(255, 255, 255));
		btnNewButton_3_2.setBackground(new Color(165, 29, 45));
		btnNewButton_3_2.setBounds(218, 192, 50, 50);
		contentPane.add(btnNewButton_3_2);
		
		btnNewButton_2_4 = new JButton(":");
		btnNewButton_2_4.setFont(new Font("DialogInput", Font.BOLD, 20));
		btnNewButton_2_4.setForeground(new Color(255, 255, 255));
		btnNewButton_2_4.setBackground(new Color(165, 29, 45));
		btnNewButton_2_4.setBounds(218, 257, 50, 112);
		contentPane.add(btnNewButton_2_4);
		
		textField = new JTextField();
		textField.setFont(new Font("DialogInput", Font.BOLD, 20));
		textField.setForeground(new Color(224, 27, 36));
		textField.setBackground(new Color(94, 92, 100));
		textField.setColumns(10);
		textField.setBounds(12, 110, 272, 66);
		contentPane.add(textField);
	}
}
