package principal;

import vistes.VistaPrincipal;
public class Principal {

	public static void main(String[] args) {
		VistaPrincipal vista = new VistaPrincipal();
		vista.setVisible(true);

	}

}
